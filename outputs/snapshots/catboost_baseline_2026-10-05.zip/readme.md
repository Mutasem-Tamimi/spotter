# Freight Rate Prediction Challenge

See `freight-rate-ml-assessment.pdf` for the assessment instructions.

## Cycle 1: data exploration and visualization

Open [`notebooks/01_data_exploration.ipynb`](notebooks/01_data_exploration.ipynb).
The notebook explains the columns, audits data quality, and explores prices,
distance, equipment, weight, dates, geography, and the two numeric signals.
It also compares development and final-input data and explains the reduced
December inputs. It does not train a model or fill prediction files.

The notebook converts negative `weight` values to positive values in the working
pandas DataFrames using `abs()`, preserves missing weights, and adds a
`weight_was_negative` flag. Original signed copies remain available for audits
and the sign-error diagnostics. The supplied CSVs are never overwritten.

A Python 3.13 virtual environment is available in `.venv`. From this project
directory in PowerShell, launch JupyterLab with:

```powershell
.\.venv\Scripts\python.exe -m jupyterlab notebooks/01_data_exploration.ipynb
```

Select the **Python (spotter)** kernel and run all cells from top to bottom.
Saved cell outputs include the tables and plots. The notebook locates the CSVs
in the project root and leaves them unchanged.

To recreate the environment on another Windows machine with Python 3.13:

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m ipykernel install --sys-prefix --name spotter --display-name "Python (spotter)"
```

To activate it in a PowerShell session, run `.\.venv\Scripts\Activate.ps1`.
Activation is optional when using the explicit interpreter commands above.
In VS Code, selecting `.venv\Scripts\python.exe` as the notebook kernel also works.

## Cycle 2: CatBoost training and measurement

Open [`notebooks/02_catboost_pipeline.ipynb`](notebooks/02_catboost_pipeline.ipynb)
and run its cells in order with the **Python (spotter)** kernel. The notebook
uses the reusable pipeline in [`freight_model.py`](freight_model.py).

The raw labeled rows are split **before fitting preprocessing or models**:

| Partition | Dates in 2025 | Rows | Purpose |
| --- | --- | ---: | --- |
| Train | January-June | 28,806 | Fit candidate models and preprocessing |
| Development | July-August | 9,671 | Early stopping and model selection |
| Test | September-October | 9,523 | Measure the selected model after refitting on January-August |

The split follows the future prediction task instead of mixing dates at random.
September-October is held out from model selection; it was already inspected in
Cycle 1, so it is not a completely untouched analysis set. `validation.csv` has
hidden targets and is not the development split or a measurable test set.

The first shared-input model uses pickup/delivery cities, equipment, distance,
absolute weight, missing/negative-weight flags, four separate coordinates, and
days since the training start, weekday, and day of month. CatBoost handles
numerical NaNs directly. Missing categories get an explicit label. Coordinate
columns/cells absent at inference are filled using a city lookup learned only
from the fitting rows; an unknown city with no supplied coordinates stays NaN.
Provided coordinates are preserved, including negative longitudes.

`load_id` and all price/output columns are excluded from features. `quote_signal`
is excluded because its relationship with price changes across months.
`market_index` is excluded from this first model because the December scenario
does not provide it. No final-input data is used to learn preprocessing.

Three predeclared CatBoost configurations compare depth 6/MAE, depth 8/MAE, and
depth 6/RMSE. Each predicts total dollars directly, uses learning rate 0.05, seed
42, up to 1,200 trees, and development MAE for early stopping with patience 100.
These are starting settings, not claims of optimal values. The selected tree
count is frozen before refitting on January-August; the test set is never passed
as an early-stopping set. Predictions have a fixed $0.01 floor in the complete
pipeline and all reported metrics.

The baseline uses the fitting data's median price per mile by equipment,
multiplied by distance. Measurements include MAE/RMSE in dollars, R-squared,
signed bias (prediction minus actual), and errors by month, equipment, distance,
missing weight, corrected negative weight, and seen/unseen lanes.

The completed first run selected **depth 6, MAE loss, and 94 trees**. Its
development MAE was **$155.66** versus **$222.73** for the baseline. After the
January-August refit, the September-October results were:

| Metric | Equipment baseline | CatBoost |
| --- | ---: | ---: |
| MAE | $229.10 | $128.08 |
| RMSE | $670.66 | $643.24 |
| R-squared | 0.8069 | 0.8223 |
| Mean signed error | +$40.93 | -$67.04 |
| Median absolute error | $115.72 | $42.52 |

CatBoost reduced test MAE by **44.1%**. Its larger RMSE and negative bias show
that large errors and underprediction remain: 128 of 9,523 test rows had an
absolute error above $1,000. No rows were removed from these measurements and
the positive prediction floor affected zero test predictions. These are local
chronological results, not a measured November-December submission score.

The notebook saves diagnostics and artifacts under `outputs/catboost/`:

- `catboost_pipeline.joblib`: the complete preprocessing and model pipeline,
  fitted on **January-August**, with the measured test-period behavior.
- `metadata.json`: selected settings, versions, feature list, limitations, and
  original source-file SHA-256 hashes.
- `split_assignments.csv`, `split_summary.csv`: reproducible raw-row partitions.
- `dev_metrics.csv`, `test_metrics.csv`, `slice_metrics.csv`: measured results.
- `dev_predictions.csv`, `test_predictions.csv`: local evaluation predictions,
  not final submission files.
- `feature_importance.csv`, `learning_curves.json`, and notebook charts.

Run the same training and save its model/tables from PowerShell without Jupyter:

```powershell
.\.venv\Scripts\python.exe freight_model.py
```

To use the saved pipeline from the project root:

```python
import joblib
import pandas as pd

pipeline = joblib.load("outputs/catboost/catboost_pipeline.joblib")
raw_loads = pd.read_csv("validation.csv")
predictions = pipeline.predict(raw_loads)
```

Only load model files you trust. Keep `freight_model.py` importable and install
the pinned dependencies when loading this artifact. The model includes its
feature preparation; pass raw named columns, not manually encoded arrays.

Run the focused pipeline checks:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Local dev/test rows contain no cities unseen in their fitting periods, so they
cannot establish unseen-city accuracy. Trees also cannot extrapolate a trend
past their observed ordinal dates, and there are no labeled November-December
observations to establish recurring end-of-year behavior. The notebook checks
that the reduced December schema works; that check does not establish accuracy.
Further tuning after inspecting test errors would require a new evaluation
plan. A future submission step can refit the locked configuration on all labeled
rows; this cycle preserves the model measured on September-October.

## Full assessment workflow

The following steps describe the eventual submission. Exploration and local
CatBoost training/evaluation are implemented; final submission predictions have
not been generated. Paths below match the supplied files
in this checkout; the assessment uses `data/` paths and underscore filenames.

## What to do

1. Train and validate your model using `train-test.csv`.
2. Predict every load in `validation.csv`. Each load has a unique `load_id`.
3. Fill the matching `predicted_rate` values in `validation-predictions-template.csv` and save it as `validation_predictions.csv`.
4. Predict every row in `december-chart-inputs.csv` by filling its `predicted_rate` column.
5. Install the scorer requirements and run:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe score.py --predictions validation_predictions.csv --december-predictions december-chart-inputs.csv
```

The scorer validates both files and creates `scorer_results/candidate_december.png`.

## Submit

- GitHub repository containing your code, dependencies, and run instructions
- `validation_predictions.csv`
- PDF or DOCX report containing your validation, data split approach and `candidate_december.png`
- 2-3 minute Loom link
